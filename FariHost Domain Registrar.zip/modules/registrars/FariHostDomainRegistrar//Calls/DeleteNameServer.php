<?php
namespace ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Calls;
use ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Core\Call;

/**
 * Description of DeleteNameServer
 *
 * @author inbs
 */
class DeleteNameServer extends Call
{
    public $action = "domains/:domain/nameservers/delete";
    
    public $type = parent::TYPE_POST;
}