<?php
namespace ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Calls;
use ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class ToggleIdProtect extends Call
{
    public $action = "domains/:domain/protectid";
    
    public $type = parent::TYPE_POST;
}