<?php
namespace ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Calls;
use ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Core\Call;

/**
 * Description of GetEmailForwarding
 *
 * @author inbs
 */
class GetEmailForwarding extends Call
{
    public $action = "domains/:domain/email";
    
    public $type = parent::TYPE_GET;
}