<?php
namespace ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Calls;
use ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Core\Call;

/**
 * Description of GetEppCode
 *
 * @author inbs
 */
class GetEppCode extends Call
{
    public $action = "domains/:domain/eppcode";
    
    public $type = parent::TYPE_GET;
}