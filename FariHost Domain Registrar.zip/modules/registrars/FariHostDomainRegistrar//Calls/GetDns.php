<?php
namespace ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Calls;
use ModulesGarden\DomainsReseller\Registrar\FariHostDomainRegistrar\Core\Call;

/**
 * Description of GetDns
 *
 * @author inbs
 */
class GetDns extends Call
{
    public $action = "domains/:domain/dns";
    
    public $type = parent::TYPE_GET;
}