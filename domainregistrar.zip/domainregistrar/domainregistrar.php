<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Domains\DomainLookup\ResultsList;
use WHMCS\Domains\DomainLookup\SearchResult;
use WHMCS\Domain\Registrar\Domain;
use WHMCS\Carbon;

function domainregistrar_MetaData()
{
    return array( 'DisplayName' => 'Domain Registrar', 'APIVersion' => '1.1' );
}

function domainregistrar_getConfigArray()
{
    return array(
        'FriendlyName' => array( 'Type' => 'System',   'Value' => 'Domain Registrar' ),
        'URL'          => array( 'Type' => 'text',     'Size' => '63', 'Description' => 'Enter remote WHMCS URL' ),
        'Username'     => array( 'Type' => 'text',     'Size' => '63', 'Description' => 'Enter your email' ),
        'Password'     => array( 'Type' => 'password', 'Size' => '25', 'Description' => 'Enter your password' ),
    );
}

/**
 * Remote API Call
*/
function domainregistrar_remotecall($action, $params, $data = array())
{
    $params['input_data'] = base64_encode(serialize($data));
    $params['action'] = $action;
    $ch = curl_init();
    curl_setopt( $ch, CURLOPT_URL, $params['remoteurl']."/modules/addons/domainreseller/api.php" );
    curl_setopt( $ch, CURLOPT_TIMEOUT, 60 );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt( $ch, CURLOPT_POST, 1 );
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $params );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
    $result = curl_exec( $ch );

    logModuleCall( "Registrar", $action,  $params,  $result );

    if(!curl_errno($result)) { 
        $remote_data = (array)json_decode($result,true);
        if (sizeof($remote_data)>0) {
            logModuleCall( "Registrar", $action,  $params,  json_decode($result,true) );
            $return = json_decode($result, true);
        } else {
            $return = array( 'result' => 'error', 'message' => $result );
        }
    } else { 
        $return = array( 'result' => 'error', 'message' => curl_error($result) );
    }
    curl_close( $ch );

    return $return;
}

/**
 * Register a domain.
 */
function domainregistrar_RegisterDomain($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $contactdata['firstname'] = $params["firstname"];
    $contactdata["lastname"] = $params["lastname"];
    $contactdata["companyname"] = $params["companyname"];
    $contactdata["email"] = $params["email"];
    $contactdata["address1"] = $params["address1"];
    $contactdata["address2"] = $params["address2"];
    $contactdata["city"] = $params["city"];
    $contactdata["state"] = $params["fullstate"]; 
    $contactdata["postcode"] = $params["postcode"]; 
    $contactdata["countryCode"] = $params["countrycode"]; 
    $contactdata["phonenumber"] = $params["fullphonenumber"]; // Format: +CC.xxxxxxxxxxxx

    $domaindata["regperiod"] = $params['regperiod'];
    $domaindata["dnsmanagement"] = (bool) $params['dnsmanagement'];
    $domaindata["emailforwarding"] = (bool) $params['emailforwarding'];
    $domaindata["idprotection"] = (bool) $params['idprotection'];
    $domaindata['nameserver1'] = $params['ns1'];
    $domaindata['nameserver2'] = $params['ns2'];
    $domaindata['nameserver3'] = $params['ns3'];
    $domaindata['nameserver4'] = $params['ns4'];
    $domaindata['nameserver5'] = $params['ns5'];
    $domaindata['domainfields'] = $params['additionalfields'];

    /*
    $premiumDomainsEnabled = (bool) $params['premiumEnabled'];
    $premiumDomainsCost = $params['premiumCost'];
    if ($premiumDomainsEnabled && $premiumDomainsCost) {
        $postfields['accepted_premium_cost'] = $premiumDomainsCost;
    }
    */

    $result = domainregistrar_remotecall('RegisterDomain', $q_data, array( 'contactdata' => $contactdata, 'domaindata' => $domaindata ));
    if ($result['result'] == 'success') {
        return array( 'success' => true );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Initiate domain transfer.
 */
function domainregistrar_TransferDomain($params)
{
    $eppCode = $params['eppcode'];
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $contactdata['firstname'] = $params["firstname"];
    $contactdata["lastname"] = $params["lastname"];
    $contactdata["companyname"] = $params["companyname"];
    $contactdata["email"] = $params["email"];
    $contactdata["address1"] = $params["address1"];
    $contactdata["address2"] = $params["address2"];
    $contactdata["city"] = $params["city"];
    $contactdata["state"] = $params["fullstate"]; 
    $contactdata["postcode"] = $params["postcode"]; 
    $contactdata["countryCode"] = $params["countrycode"]; 
    $contactdata["phonenumber"] = $params["fullphonenumber"];

    $domaindata["regperiod"] = $params['regperiod'];
    $domaindata["eppcode"] = $params['eppcode'];
    $domaindata["dnsmanagement"] = (bool) $params['dnsmanagement'];
    $domaindata["emailforwarding"] = (bool) $params['emailforwarding'];
    $domaindata["idprotection"] = (bool) $params['idprotection'];
    $domaindata['nameserver1'] = $params['ns1'];
    $domaindata['nameserver2'] = $params['ns2'];
    $domaindata['nameserver3'] = $params['ns3'];
    $domaindata['nameserver4'] = $params['ns4'];
    $domaindata['nameserver5'] = $params['ns5'];
    $domaindata['domainfields'] = $params['additionalfields'];

    $result = domainregistrar_remotecall('TransferDomain', $q_data, array( 'contactdata' => $contactdata, 'domaindata' => $domaindata ));
    if ($result['result'] == 'success') {
        return array( 'success' => true );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Renew a domain.
 */
function domainregistrar_RenewDomain($params)
{
    $eppCode = $params['eppcode'];
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $domaindata["regperiod"] = $params['regperiod'];
    $domaindata["dnsmanagement"] = (bool) $params['dnsmanagement'];
    $domaindata["emailforwarding"] = (bool) $params['emailforwarding'];
    $domaindata["idprotection"] = (bool) $params['idprotection'];

    $result = domainregistrar_remotecall('RenewDomain', $q_data, array( 'domaindata' => $domaindata ));
    if ($result['result'] == 'success') {
        return array( 'success' => true );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Fetch domain information.
 */
function  domainregistrar_GetDomainInformation($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $result = domainregistrar_remotecall('GetDomainInformation', $q_data);
    $domain = (new Domain)->setDomain($params['sld'] . '.' .$params['tld']);

    if ($result['result'] == 'success') {
        $domain->setRegistrationStatus($result['RegistrationStatus'])->setTransferLock($result['TransferLock'])->setRestorable($result['Restorable'])->setIdProtectionStatus($result['IdProtectionStatus'])->setDnsManagementStatus($result['DnsManagementStatus'])->setEmailForwardingStatus($result['EmailForwardingStatus'])->setIsIrtpEnabled($result['IsIrtpEnabled'])->setIrtpOptOutStatus($result['IrtpOptOutStatus'])->setIrtpTransferLock($result['IrtpTransferLock'])->setDomainContactChangePending($result['DomainContactChangePending'])->setPendingSuspension($result['PendingSuspension'])->setRegistrantEmailAddress($result['RegistrantEmailAddress']);
        try {
            $domain->setIrtpVerificationTriggerFields((array)$result['IrtpVerificationTriggerFields']);
        } catch (Exception $e){
            //
        }
        if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$result['ExpiryDate'])) {
            $domain->setExpiryDate(WHMCS\Carbon::createFromFormat('Y-m-d', $result['ExpiryDate']));
        }
        if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$result['TransferLockExpiryDate'])) {
            $domain->setTransferLockExpiryDate(WHMCS\Carbon::createFromFormat('Y-m-d', $result['TransferLockExpiryDate']));
        }
        if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$result['IrtpTransferLockExpiryDate'])) {
            $domain->setIrtpTransferLockExpiryDate(WHMCS\Carbon::createFromFormat('Y-m-d', $result['IrtpTransferLockExpiryDate']));
        }
        if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$result['DomainContactChangeExpiryDate'])) {
            $domain->setDomainContactChangeExpiryDate(WHMCS\Carbon::createFromFormat('Y-m-d', $result['DomainContactChangeExpiryDate']));
        }
    }
    return $domain;
}

/**
 * Fetch current nameservers.
 */
function domainregistrar_GetNameservers($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $result = domainregistrar_remotecall('GetNameservers', $q_data);

    if ($result['result'] == 'success') {
        return array(
            'success' => true,
            'ns1' => $result['ns1'],
            'ns2' => $result['ns2'],
            'ns3' => $result['ns3'],
            'ns4' => $result['ns4'],
            'ns5' => $result['ns5'],
        );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Save nameserver changes.
 */
function domainregistrar_SaveNameservers($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $data['ns1'] = $params['ns1'];
    $data['ns2'] = $params['ns2'];
    $data['ns3'] = $params['ns3'];
    $data['ns4'] = $params['ns4'];
    $data['ns5'] = $params['ns5'];

    $result = domainregistrar_remotecall('SaveNameservers', $q_data, $data);

    if ($result['result'] == 'success') {
        return array( 'success' => true );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Get the current WHOIS Contact Information.
 */
function domainregistrar_GetContactDetails($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $result = domainregistrar_remotecall('GetContactDetails', $q_data);

    if ($result['result'] == 'success') {
        unset($result['result']);
        return $result;
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Update the WHOIS Contact Information for a given domain.
 */
function domainregistrar_SaveContactDetails($params)
{
    $contactDetails = $params['contactdetails'];
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $data = $params['contactdetails'];

    $result = domainregistrar_remotecall('SaveContactDetails', $q_data, $data);

    if ($result['result'] == 'success') {
        return array( 'success' => true );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Get registrar lock status.
 */
function domainregistrar_GetRegistrarLock($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $result = domainregistrar_remotecall('GetRegistrarLock', $q_data);

    if ($result['result'] == 'success') {
        if ($result['lockstatus'] == 'Unknown') {
            return false ;
        } else {
            return $result['lockstatus'];
        }
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Set registrar lock status.
 */
function domainregistrar_SaveRegistrarLock($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $data['lockstatus'] = ($params['lockenabled'] == 'locked') ? 1 : 0;

    $result = domainregistrar_remotecall('SaveRegistrarLock', $q_data, $data);

    if ($result['result'] == 'success') {
        return array( 'success' => true );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Enable/Disable ID Protection.
 */
function domainregistrar_IDProtectToggle($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $data['idprotect'] = (bool) $params['protectenable'];

    $result = domainregistrar_remotecall('IDProtectToggle', $q_data, $data);

    if ($result['result'] == 'success') {
        return array( 'success' => true );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Request EEP Code.
 */
function domainregistrar_GetEPPCode($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $result = domainregistrar_remotecall('GetEPPCode', $q_data);

    if ($result['result'] == 'success') {
        unset($result['result']);
        return $result;
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}

/**
 * Sync Domain Status & Expiration Date.
 */
function domainregistrar_Sync($params)
{
    $q_data['username']  = $params['Username'];
    $q_data['password']  = $params['Password'];
    $q_data['remoteurl'] = $params['URL'];
    $q_data['domain']    = $params['sld'] . '.' .$params['tld'];

    $result = domainregistrar_remotecall('GetDomainInformation', $q_data);

    if ($result['result'] == 'success') {
        return array(
            'expirydate' => $result['ExpiryDate'],
            'active' => ($result['RegistrationStatus'] == 'Active'), 
            'transferredAway' => ($result['RegistrationStatus'] == 'Transferred Away')
        );
    } else {
        return array( 'error' => ($result['error']?$result['error']:$result['message']));
    }
}
